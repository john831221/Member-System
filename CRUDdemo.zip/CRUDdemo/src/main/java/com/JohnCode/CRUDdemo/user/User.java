package com.JohnCode.CRUDdemo.user;

import jakarta.persistence.*;

@Entity
@Table(name = "member_tb")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "member_password",nullable = false, unique = true,length = 30)
    private String password;
    @Column(name = "member_name",nullable = false,length = 20)
    private String name;
    @Column(name = "member_gender",nullable = false,length = 1)
    private String gender;
    @Column(name = "member_age",nullable = false,length = 3)
    private String age;
    @Column(name = "member_email",nullable = false,length = 100)
    private String email;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
