package com.JohnCode.CRUDdemo.user;

public class UserNotFounfException extends Throwable {
    public UserNotFounfException(String message) {
        super(message);
    }
}
