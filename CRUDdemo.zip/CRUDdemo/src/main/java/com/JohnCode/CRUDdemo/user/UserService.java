package com.JohnCode.CRUDdemo.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository repo;
    public  List<User> listAll(){
        return (List<User>) repo.findAll();
    }
    public void save(User user){
        repo.save(user);
    }
    public User get(Integer id) throws UserNotFounfException{
        Optional<User> userById = repo.findById(id);
        if(userById.isPresent()){
            return userById.get();
        }

        throw new UserNotFounfException("找不到ID:"+id);
    }
    public void delete(Integer id) throws UserNotFounfException {
        Long count = repo.countById(id);
        if(count == null || count == 0){
            throw new UserNotFounfException("找不到ID:"+id);
        }
        repo.deleteById(id);
    }
}

