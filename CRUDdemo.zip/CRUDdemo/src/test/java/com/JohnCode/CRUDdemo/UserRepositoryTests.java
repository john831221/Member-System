package com.JohnCode.CRUDdemo;

import com.JohnCode.CRUDdemo.user.UserRepository;
import com.JohnCode.CRUDdemo.user.UserService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.jdbc.DataJdbcTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;
import com.JohnCode.CRUDdemo.user.User;
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = false)
public class UserRepositoryTests {
    @Autowired
    private UserRepository repo;
    @Test
    public void testAddUser(){
        User user = new User();
        user.setEmail("jkkk@yahoo.com");
        user.setAge("52");
        user.setGender("F");
        user.setName("JK Rolling");
        user.setPassword("kkkkww22444");
        User savedUser = repo.save(user);
        Assertions.assertThat(savedUser).isNotNull();
        Assertions.assertThat(savedUser.getId()).isGreaterThan(0);
    }
}
